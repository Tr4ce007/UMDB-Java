package dev.umdb.umdb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UmdbApplication {

	public static void main(String[] args) {
		SpringApplication.run(UmdbApplication.class, args);
	}

}
